package com.example.backenduserlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendUserLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
