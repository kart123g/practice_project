package com.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Userlog;
import com.service.UserLoginService;

@RestController
@RequestMapping("userlogin")
@CrossOrigin
public class UserLoginController {
	
	//Here We assign APIs ,on which API ,our login and create Account works
	
	@Autowired
	UserLoginService userLoginService;
	
	@PostMapping(value = "login",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String signIn(@RequestBody Userlog userLogin) {
		System.out.println("login work perfectly");
		return userLoginService.UsersignIn(userLogin);
		
	}
	
	@PostMapping(value = "createAccount",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String signUp(@RequestBody Userlog userLogin) {
		System.out.println("SignUp  work perfectly");
		return userLoginService.UsersignUp(userLogin);
	}
	
	@PatchMapping(value = "updateData",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String updateAadhar(@RequestBody Userlog userLogin) {
		return userLoginService.updateData(userLogin);
	}
	
}
