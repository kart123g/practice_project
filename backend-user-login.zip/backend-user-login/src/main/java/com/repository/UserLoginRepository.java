package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
import com.bean.Userlog;

@Repository
public interface UserLoginRepository extends JpaRepository<Userlog, String>{
	//Connect Using JPA
	//Our Server on MYSQL
	
}
