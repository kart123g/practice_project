package com.service;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Userlog;
import com.repository.UserLoginRepository;

@Service
public class UserLoginService {
	
	//Here  we type our logic of user validation
	
	@Autowired
	UserLoginRepository	userLoginRepository;
	
	public String UsersignIn(Userlog userLogin) {
		Optional<Userlog> result = userLoginRepository.findById(userLogin.getEmail());
		if(result.isPresent()) {
			Userlog ll = result.get();
					if(ll.getPassword().equals(userLogin.getPassword())) {		
							return "User successfully login";
						}					
					else {
						return "InValid password";
					}
		}
		else {
			return "Invalid details";
		}
	}
	public String UsersignUp(Userlog userLogin) {
		Optional<Userlog> result = userLoginRepository.findById(userLogin.getEmail());
		if(result.isPresent()) {
					return "Email Id alreay exists";
		}else {
				userLoginRepository.save(userLogin);
				return "Account created successfully";
			}
	}
	
	
	public String updateData(Userlog userLogin) {
		Optional<Userlog> result  = userLoginRepository.findById(userLogin.getEmail());
		if(result.isPresent()) {
			Userlog ul = result.get();
			ul.setMobile(userLogin.getMobile());
			ul.setPassword(userLogin.getPassword());
			ul.setAddress(userLogin.getAddress());
			ul.setEmail(userLogin.getEmail());
			
			userLoginRepository.saveAndFlush(ul);
			return "User Data updated successfully";
		}else {
			return "User Data not present";
		}
	}
	
}
